"""
main.py — Virtual Pet AI · FastAPI Deployment
==============================================
Endpoint yang tersedia:

  GET  /                        → info API
  GET  /health                  → status model & sistem
  POST /predict                 → prediksi tunggal
  POST /predict/batch           → prediksi batch (max 100 record)
  GET  /docs                    → Swagger UI (otomatis)
  GET  /redoc                   → ReDoc UI (otomatis)

Cara menjalankan:
  uvicorn main:app --reload --host 0.0.0.0 --port 8000

Environment variables (opsional):
  API_VERSION=1.0.0
  LOG_LEVEL=INFO
  MAX_BATCH_SIZE=100
"""

import os
import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from schemas import (
    PredictionRequest,
    PredictionResponse,
    BatchPredictionRequest,
    BatchPredictionResponse,
    HealthResponse,
)
from predictor import VirtualPetPredictor


# ─── Konfigurasi Logging ──────────────────────────────────────────────────────

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("main")

API_VERSION    = os.getenv("API_VERSION", "1.0.0")
MAX_BATCH_SIZE = int(os.getenv("MAX_BATCH_SIZE", "100"))


# ─── Lifespan (startup / shutdown) ────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Muat model saat startup, bersihkan saat shutdown."""
    logger.info("=" * 50)
    logger.info("  Virtual Pet AI — memuat model …")
    logger.info("=" * 50)

    # Panggil singleton predictor agar model dimuat sekali
    predictor = VirtualPetPredictor.get()
    app.state.predictor = predictor

    logger.info("✅ Model siap melayani request")
    yield
    logger.info("🛑 Aplikasi dihentikan")


# ─── Aplikasi FastAPI ─────────────────────────────────────────────────────────

app = FastAPI(
    title="Virtual Pet AI — Financial Health Classifier",
    description="""
## Virtual Pet AI API

Mengklasifikasikan **kesehatan keuangan pengguna** berdasarkan profil belanja
dan perilaku transaksi harian, kemudian menerjemahkannya menjadi status
**Virtual Pet** secara real-time.

### Alur kerja
1. Kirim data profil pengguna ke `/predict`
2. Model ANN mengklasifikasikan perilaku belanja (Hybrid / Online / Store)
3. Engine heuristik menghitung skor kesehatan keuangan (Sehat / Waspada / Boros)
4. Response berisi update status Virtual Pet beserta tips personal

### Kelas Kesehatan Keuangan
| Label    | Spending Ratio | Pet Status |
|----------|---------------|------------|
| Sehat    | < 60%         | Happy 😸  |
| Waspada  | 60–80%        | Neutral 😐 |
| Boros    | > 80%         | Sad 😿    |
    """,
    version=API_VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)


# ─── Middleware ────────────────────────────────────────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # Ganti dengan domain spesifik di produksi
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log setiap request masuk beserta durasi respons."""
    t0 = time.perf_counter()
    response = await call_next(request)
    elapsed  = (time.perf_counter() - t0) * 1000
    logger.info(
        f"{request.method} {request.url.path} "
        f"→ {response.status_code} ({elapsed:.1f} ms)"
    )
    return response


# ─── Exception Handler ────────────────────────────────────────────────────────

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled error: {exc}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "detail": "Terjadi kesalahan internal. Silakan coba lagi.",
            "error":  str(exc),
        },
    )


# ─── Endpoints ────────────────────────────────────────────────────────────────

@app.get("/", tags=["Info"])
async def root():
    """Informasi dasar API."""
    return {
        "name":        "Virtual Pet AI",
        "version":     API_VERSION,
        "description": "Financial Health Classifier untuk Virtual Pet",
        "docs":        "/docs",
        "health":      "/health",
    }


@app.get(
    "/health",
    response_model=HealthResponse,
    tags=["Info"],
    summary="Cek status model & sistem",
)
async def health_check(request: Request) -> HealthResponse:
    """
    Cek apakah model sudah dimuat dan siap menerima request.
    Berguna untuk load balancer / liveness probe Kubernetes.
    """
    predictor: VirtualPetPredictor = request.app.state.predictor
    return HealthResponse(
        status="ok",
        model_loaded=predictor is not None,
        version=API_VERSION,
        classes=predictor.class_names,
        n_features=len(predictor.feature_names),
    )


@app.post(
    "/predict",
    response_model=PredictionResponse,
    tags=["Prediksi"],
    summary="Prediksi kesehatan keuangan satu pengguna",
    status_code=status.HTTP_200_OK,
)
async def predict(
    request:     Request,
    body:        PredictionRequest,
) -> PredictionResponse:
    """
    Terima profil satu pengguna dan kembalikan:
    - **shopping_behavior** → perilaku belanja (Hybrid/Online/Store) + probabilitas
    - **financial_health**  → skor & label kesehatan keuangan
    - **virtual_pet**       → perubahan status & mood pet, tips personal
    """
    try:
        predictor: VirtualPetPredictor = request.app.state.predictor
        return predictor.predict(body)

    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Predict error: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Prediksi gagal: {e}",
        )


@app.post(
    "/predict/batch",
    response_model=BatchPredictionResponse,
    tags=["Prediksi"],
    summary=f"Prediksi batch (max {MAX_BATCH_SIZE} record)",
    status_code=status.HTTP_200_OK,
)
async def predict_batch(
    request: Request,
    body:    BatchPredictionRequest,
) -> BatchPredictionResponse:
    """
    Prediksi untuk banyak pengguna sekaligus.

    - Tiap record diproses independen — record yang gagal tidak membatalkan batch.
    - Field `failed` berisi index + pesan error untuk record yang gagal.
    - Maksimum **{MAX_BATCH_SIZE} record** per request.
    """
    if len(body.records) > MAX_BATCH_SIZE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Maksimum {MAX_BATCH_SIZE} record per batch.",
        )

    predictor: VirtualPetPredictor = request.app.state.predictor
    results, failed = predictor.predict_batch(body.records)

    return BatchPredictionResponse(
        total=len(body.records),
        results=results,
        failed=failed,
    )


@app.get(
    "/features",
    tags=["Info"],
    summary="Daftar fitur yang digunakan model",
)
async def list_features(request: Request):
    """Kembalikan nama dan urutan fitur input yang diharapkan model."""
    predictor: VirtualPetPredictor = request.app.state.predictor
    return {
        "n_features":   len(predictor.feature_names),
        "feature_names": predictor.feature_names,
        "categorical": ["gender", "city_tier"],
        "gender_options":    ["Male", "Female", "Other"],
        "city_tier_options": ["Tier 1", "Tier 2", "Tier 3"],
    }
