"""
schemas.py
----------
Definisi skema request & response API menggunakan Pydantic v2.
Semua validasi input dilakukan di sini sebelum data menyentuh model.
"""

from pydantic import BaseModel, Field, field_validator, model_validator
from typing import Literal
from enum import Enum


# ─── Enums ───────────────────────────────────────────────────────────────────

class GenderEnum(str, Enum):
    male   = "Male"
    female = "Female"
    other  = "Other"


class CityTierEnum(str, Enum):
    tier1 = "Tier 1"
    tier2 = "Tier 2"
    tier3 = "Tier 3"


class ShoppingBehavior(str, Enum):
    hybrid = "Hybrid"
    online = "Online"
    store  = "Store"


class FinancialHealth(str, Enum):
    sehat    = "Sehat"
    waspada  = "Waspada"
    boros    = "Boros"


class PetStatus(str, Enum):
    happy    = "Happy"
    neutral  = "Neutral"
    sad      = "Sad"
    critical = "Critical"


# ─── Request ─────────────────────────────────────────────────────────────────

class PredictionRequest(BaseModel):
    """
    Input transaksi & profil pengguna untuk prediksi kesehatan keuangan
    dan perilaku belanja Virtual Pet.
    """

    # Demografi
    age:                    int   = Field(..., ge=18, le=100,  description="Usia pengguna (tahun)")
    gender:                 GenderEnum                          = Field(..., description="Jenis kelamin")
    city_tier:              CityTierEnum                        = Field(..., description="Tier kota domisili")

    # Digital behavior
    daily_internet_hours:   float = Field(..., ge=0,  le=24,   description="Jam internet per hari")
    smartphone_usage_years: float = Field(..., ge=0,  le=30,   description="Lama pakai smartphone (tahun)")
    social_media_hours:     float = Field(..., ge=0,  le=24,   description="Jam media sosial per hari")

    # Kepercayaan & literasi digital
    online_payment_trust_score:    float = Field(..., ge=0, le=10, description="Kepercayaan pada pembayaran online (0–10)")
    tech_savvy_score:              float = Field(..., ge=0, le=10, description="Melek teknologi (0–10)")

    # Perilaku belanja
    monthly_online_orders:         int   = Field(..., ge=0,         description="Jumlah order online per bulan")
    monthly_store_visits:          int   = Field(..., ge=0,         description="Kunjungan toko fisik per bulan")
    avg_online_spend:              float = Field(..., ge=0,         description="Rata-rata pengeluaran online per transaksi (IDR)")
    avg_store_spend:               float = Field(..., ge=0,         description="Rata-rata pengeluaran toko per kunjungan (IDR)")
    monthly_income:                float = Field(..., ge=500_000,   description="Pendapatan bulanan (IDR)")

    # Preferensi belanja
    discount_sensitivity:          float = Field(..., ge=0, le=10,  description="Sensitivitas diskon (0=tidak peduli, 10=sangat sensitif)")
    return_frequency:              float = Field(..., ge=0,         description="Frekuensi retur produk per bulan")
    avg_delivery_days:             float = Field(..., ge=0, le=60,  description="Rata-rata hari pengiriman yang diterima")
    delivery_fee_sensitivity:      float = Field(..., ge=0, le=10,  description="Sensitivitas ongkos kirim (0–10)")
    free_return_importance:        float = Field(..., ge=0, le=10,  description="Kepentingan retur gratis (0–10)")
    product_availability_online:   float = Field(..., ge=0, le=10,  description="Ketersediaan produk online (0–10)")
    impulse_buying_score:          float = Field(..., ge=0, le=10,  description="Kecenderungan impulsif belanja (0–10)")
    need_touch_feel_score:         float = Field(..., ge=0, le=10,  description="Perlu pegang/coba produk (0–10)")
    brand_loyalty_score:           float = Field(..., ge=0, le=10,  description="Loyalitas merek (0–10)")
    environmental_awareness:       float = Field(..., ge=0, le=10,  description="Kesadaran lingkungan (0–10)")
    time_pressure_level:           float = Field(..., ge=0, le=10,  description="Tingkat tekanan waktu (0–10)")

    @field_validator("daily_internet_hours", "social_media_hours")
    @classmethod
    def internet_le_24(cls, v: float) -> float:
        if v > 24:
            raise ValueError("Tidak boleh melebihi 24 jam")
        return v

    @model_validator(mode="after")
    def social_le_internet(self) -> "PredictionRequest":
        if self.social_media_hours > self.daily_internet_hours:
            raise ValueError(
                "social_media_hours tidak boleh melebihi daily_internet_hours"
            )
        return self

    model_config = {
        "json_schema_extra": {
            "example": {
                "age": 28,
                "gender": "Male",
                "city_tier": "Tier 2",
                "monthly_income": 8_500_000,
                "daily_internet_hours": 6,
                "smartphone_usage_years": 5,
                "social_media_hours": 3,
                "online_payment_trust_score": 8,
                "tech_savvy_score": 7,
                "monthly_online_orders": 6,
                "monthly_store_visits": 2,
                "avg_online_spend": 450_000,
                "avg_store_spend": 250_000,
                "discount_sensitivity": 6,
                "return_frequency": 1,
                "avg_delivery_days": 3,
                "delivery_fee_sensitivity": 5,
                "free_return_importance": 7,
                "product_availability_online": 8,
                "impulse_buying_score": 4,
                "need_touch_feel_score": 5,
                "brand_loyalty_score": 6,
                "environmental_awareness": 5,
                "time_pressure_level": 6,
            }
        }
    }


# ─── Response ─────────────────────────────────────────────────────────────────

class ShoppingBehaviorDetail(BaseModel):
    label:      ShoppingBehavior
    confidence: float = Field(..., description="Kepercayaan prediksi (0–1)")
    probabilities: dict[str, float] = Field(..., description="Probabilitas tiap kelas")


class FinancialHealthDetail(BaseModel):
    label:         FinancialHealth
    spending_ratio: float = Field(..., description="Rasio total pengeluaran / pendapatan")
    impulse_risk:  str    = Field(..., description="Tingkat risiko impulsif (Rendah/Sedang/Tinggi)")
    score:         float  = Field(..., description="Skor kesehatan keuangan (0–100, makin tinggi makin sehat)")


class VirtualPetUpdate(BaseModel):
    status:      PetStatus
    mood_change: int    = Field(..., description="Perubahan mood pet (-30 s/d +20)")
    message:     str    = Field(..., description="Pesan notifikasi untuk pengguna")
    emoji:       str    = Field(..., description="Ekspresi pet")
    tips:        list[str] = Field(..., description="Tips keuangan personal untuk pengguna")


class PredictionResponse(BaseModel):
    request_id:       str
    shopping_behavior: ShoppingBehaviorDetail
    financial_health:  FinancialHealthDetail
    virtual_pet:       VirtualPetUpdate
    processing_time_ms: float


class HealthResponse(BaseModel):
    status:       str
    model_loaded: bool
    version:      str
    classes:      list[str]
    n_features:   int


class BatchPredictionRequest(BaseModel):
    records: list[PredictionRequest] = Field(..., min_length=1, max_length=100)


class BatchPredictionResponse(BaseModel):
    total:   int
    results: list[PredictionResponse]
    failed:  list[dict]
