"""
predictor.py
------------
Singleton predictor: memuat semua artefak model sekali saat startup
dan menyediakan metode prediksi yang thread-safe.

Alur prediksi:
  Input JSON
    → validasi (Pydantic di schemas.py)
    → encode kategorikal (LabelEncoder)
    → susun vektor fitur (urutan sesuai metadata)
    → normalisasi (StandardScaler)
    → inferensi ANN  → probabilitas 3 kelas perilaku belanja
    → hitung skor kesehatan keuangan dari fitur numerik
    → mapping → status Virtual Pet
    → response JSON
"""

import json
import time
import uuid
import logging
import numpy as np
import joblib
import tensorflow as tf
from pathlib import Path
from typing import Any

from schemas import (
    PredictionRequest, PredictionResponse,
    ShoppingBehaviorDetail, FinancialHealthDetail, VirtualPetUpdate,
    ShoppingBehavior, FinancialHealth, PetStatus,
)

tf.get_logger().setLevel("ERROR")
logger = logging.getLogger("predictor")

ARTIFACT_DIR = Path(__file__).parent / "artifacts"


# ─── Mapping Tables ───────────────────────────────────────────────────────────

# Perilaku belanja → kontribusi skor keuangan
BEHAVIOR_FINANCIAL_IMPACT = {
    "Hybrid": 0,    # netral
    "Online": -5,   # sedikit lebih impulsif (flash sale, dll.)
    "Store":  +5,   # lebih terencana
}

# Kesehatan keuangan → status & mood Virtual Pet
HEALTH_TO_PET: dict[str, dict] = {
    "Sehat": {
        "status":      PetStatus.happy,
        "mood_change": +15,
        "emoji":       "🐱✨",
        "message":     "Keuanganmu sehat! Pet-mu senang melihat kamu berhemat.",
        "tips": [
            "Pertahankan rasio tabungan di atas 20% pendapatan.",
            "Coba investasikan surplus ke reksa dana atau deposito.",
        ],
    },
    "Waspada": {
        "status":      PetStatus.neutral,
        "mood_change": -5,
        "emoji":       "🐱😐",
        "message":     "Ada indikasi pengeluaran mulai tinggi. Yuk lebih hati-hati!",
        "tips": [
            "Buat daftar belanja sebelum berbelanja online.",
            "Hindari flash sale impulsif — tunggu 24 jam sebelum membeli.",
            "Cek kembali langganan yang tidak terpakai.",
        ],
    },
    "Boros": {
        "status":      PetStatus.sad,
        "mood_change": -25,
        "emoji":       "🐱😿",
        "message":     "Pengeluaranmu melebihi batas aman. Pet-mu khawatir!",
        "tips": [
            "Terapkan aturan 50/30/20: kebutuhan/keinginan/tabungan.",
            "Nonaktifkan notifikasi promosi dari aplikasi belanja.",
            "Catat setiap pengeluaran harian selama 2 minggu ke depan.",
            "Pertimbangkan konsultasi dengan perencana keuangan.",
        ],
    },
}

# Skor impulsif → label risiko
IMPULSE_RISK_MAP = {
    (0.0, 3.5):  "Rendah",
    (3.5, 6.5):  "Sedang",
    (6.5, 10.1): "Tinggi",
}


def _impulse_risk_label(score: float) -> str:
    for (lo, hi), label in IMPULSE_RISK_MAP.items():
        if lo <= score < hi:
            return label
    return "Tinggi"


class VirtualPetPredictor:
    """
    Singleton predictor. Panggil VirtualPetPredictor.get() untuk instance.
    """

    _instance: "VirtualPetPredictor | None" = None

    def __init__(self):
        logger.info("Memuat artefak model …")
        t0 = time.perf_counter()

        # Model ANN
        self.model: tf.keras.Model = tf.keras.models.load_model(
            str(ARTIFACT_DIR / "virtual_pet_ann.h5")
        )

        # Preprocessing
        self.scaler         = joblib.load(ARTIFACT_DIR / "scaler.pkl")
        self.label_encoders = joblib.load(ARTIFACT_DIR / "label_encoders.pkl")

        # Metadata
        with open(ARTIFACT_DIR / "model_metadata.json") as f:
            meta = json.load(f)
        self.class_names:  list[str] = meta["class_names"]    # Hybrid, Online, Store
        self.feature_names: list[str] = meta["feature_names"]

        elapsed = (time.perf_counter() - t0) * 1000
        logger.info(f"Model dimuat dalam {elapsed:.1f} ms")
        logger.info(f"  Kelas   : {self.class_names}")
        logger.info(f"  Fitur   : {len(self.feature_names)}")

    @classmethod
    def get(cls) -> "VirtualPetPredictor":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    # ── Preprocessing ──────────────────────────────────────────────────────────

    def _encode_and_vectorize(self, req: PredictionRequest) -> np.ndarray:
        """
        Ubah PredictionRequest menjadi array numerik ternormalisasi (1 × n_features).
        """
        raw: dict[str, Any] = req.model_dump()

        # Encode kolom kategorik
        for col, le in self.label_encoders.items():
            raw[col] = int(le.transform([raw[col]])[0])

        # Susun vektor sesuai urutan feature_names
        vec = np.array(
            [raw[fname] for fname in self.feature_names],
            dtype=np.float32,
        ).reshape(1, -1)

        return self.scaler.transform(vec).astype(np.float32)

    # ── Skor Kesehatan Keuangan ────────────────────────────────────────────────

    @staticmethod
    def _compute_financial_health(
        req: PredictionRequest,
        behavior: str,
    ) -> tuple[FinancialHealth, float, float]:
        """
        Hitung skor & label kesehatan keuangan dari fitur input.

        Returns:
            (label, spending_ratio, skor_0_100)
        """
        # Total pengeluaran estimasi per bulan
        total_spend = (
            req.avg_online_spend * req.monthly_online_orders +
            req.avg_store_spend  * req.monthly_store_visits
        )
        spending_ratio = total_spend / max(req.monthly_income, 1)

        # Skor dasar dari spending ratio (makin rendah makin sehat)
        if spending_ratio < 0.40:
            base_score = 90
        elif spending_ratio < 0.60:
            base_score = 70
        elif spending_ratio < 0.80:
            base_score = 50
        else:
            base_score = 25

        # Penalti / bonus dari faktor perilaku
        impulse_penalty  = req.impulse_buying_score  * 1.5   # max -15
        discount_bonus   = req.discount_sensitivity  * 0.8   # max +8
        behavior_delta   = BEHAVIOR_FINANCIAL_IMPACT[behavior]

        final_score = max(0, min(100,
            base_score
            - impulse_penalty
            + discount_bonus
            + behavior_delta
        ))

        # Tentukan label
        if final_score >= 65:
            label = FinancialHealth.sehat
        elif final_score >= 40:
            label = FinancialHealth.waspada
        else:
            label = FinancialHealth.boros

        return label, round(spending_ratio, 4), round(final_score, 1)

    # ── Prediksi Utama ─────────────────────────────────────────────────────────

    def predict(self, req: PredictionRequest) -> PredictionResponse:
        """
        Prediksi lengkap: perilaku belanja + kesehatan keuangan + status Virtual Pet.
        """
        t0 = time.perf_counter()

        # 1. Vektorisasi
        X = self._encode_and_vectorize(req)

        # 2. Inferensi ANN
        proba: np.ndarray = self.model.predict(X, verbose=0)[0]  # shape (3,)
        pred_idx   = int(np.argmax(proba))
        pred_label = self.class_names[pred_idx]

        shopping = ShoppingBehaviorDetail(
            label=ShoppingBehavior(pred_label),
            confidence=round(float(proba[pred_idx]), 4),
            probabilities={
                cls: round(float(p), 4)
                for cls, p in zip(self.class_names, proba)
            },
        )

        # 3. Kesehatan keuangan
        fh_label, spending_ratio, fh_score = self._compute_financial_health(
            req, pred_label
        )

        financial = FinancialHealthDetail(
            label=fh_label,
            spending_ratio=spending_ratio,
            impulse_risk=_impulse_risk_label(req.impulse_buying_score),
            score=fh_score,
        )

        # 4. Virtual Pet update
        pet_cfg = HEALTH_TO_PET[fh_label.value]
        pet = VirtualPetUpdate(**pet_cfg)

        elapsed_ms = round((time.perf_counter() - t0) * 1000, 2)

        return PredictionResponse(
            request_id=str(uuid.uuid4()),
            shopping_behavior=shopping,
            financial_health=financial,
            virtual_pet=pet,
            processing_time_ms=elapsed_ms,
        )

    def predict_batch(
        self,
        requests: list[PredictionRequest],
    ) -> tuple[list[PredictionResponse], list[dict]]:
        """Prediksi batch. Gagal per-record tidak menghentikan batch."""
        results, failed = [], []
        for i, req in enumerate(requests):
            try:
                results.append(self.predict(req))
            except Exception as exc:
                logger.error(f"Batch record {i} gagal: {exc}")
                failed.append({"index": i, "error": str(exc)})
        return results, failed
