const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
require('dotenv').config();

// Panggil berkas rute baru kita
const analisisRoutes = require('./routes/analisisRoutes');
const transaksiRoutes = require('./routes/transaksiRoutes'); //
const authRoutes = require('./routes/authRoutes');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);

app.listen(5000, () => {
  console.log('Server berjalan di port 5000');
});

// ========================================================
// KONFIGURASI & KONEKSI POSTGRESQL
// ========================================================
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

const inisialisasiDatabase = async () => {
  // 1. Tambah Query Buat Tabel Pengguna
  const queryBuatTabelPengguna = `
    CREATE TABLE IF NOT EXISTS pengguna (
      id SERIAL PRIMARY KEY,
      nama VARCHAR(100) NOT NULL,
      email VARCHAR(150) UNIQUE NOT NULL,
      password VARCHAR(255) NOT NULL,
      tanggal_buat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `;

  const queryBuatTabelTransaksi = `
    CREATE TABLE IF NOT EXISTS transaksi (
      id SERIAL PRIMARY KEY,
      pengguna_id INT REFERENCES pengguna(id) ON DELETE CASCADE,
      deskripsi VARCHAR(255) NOT NULL,
      jumlah NUMERIC NOT NULL,
      tipe VARCHAR(50) NOT NULL,
      tanggal TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `;

  try {
    await pool.query(queryBuatTabelPengguna);
    await pool.query(queryBuatTabelTransaksi);
    console.log('✅ Tabel "pengguna" dan "transaksi" siap digunakan di PostgreSQL.');
  } catch (error) {
    console.error('❌ Gagal menginisialisasi database:', error.message);
  }
};

inisialisasiDatabase();

// ========================================================
// 1. RUTE DASAR
// ========================================================
app.get('/', (req, res) => {
  res.json({
    status: 'success',
    message: 'Backend Ledgerly dengan Arsitektur MVC Rapi Siap!'
  });
});

// (Rute transaksi manual lokal tetap bisa dibiarkan di sini sementara)

// ========================================================
// 2. REGISTRASI RUTE MODULAR (Menghubungkan folder routes)
// ========================================================
// Semua rute di dalam analisisRoutes akan otomatis diawali dengan teks '/api'
app.use('/api', analisisRoutes);
app.use('/api', transaksiRoutes)
app.use('/api', authRoutes);

// Jalankan Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`==================================================`);
  console.log(`🚀 Server Backend Ledgerly (MVC Mode) Berhasil Dihidupkan!`);
  console.log(`🌐 Berjalan di: http://localhost:${PORT}`);
  console.log(`==================================================`);
});