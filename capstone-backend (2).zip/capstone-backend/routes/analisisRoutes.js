const express = require('express');
const router = express.Router();

// Panggil controller yang berisi logika pemrosesan data
const analisisController = require('../controllers/analisisController');

// Definisikan rute URL dan hubungkan ke fungsi di controller
router.post('/analisis-keuangan', analisisController.prosesAnalisisKeuangan);

// Ekspor router agar bisa dikenalkan di server.js utama
module.exports = router;