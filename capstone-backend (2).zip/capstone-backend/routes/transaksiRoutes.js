// routes/transaksiRoutes.js
const express = require('express');
const router = express.Router();
const transaksiController = require('../controllers/transaksiController');

// URL: /api/transaksi
router.post('/transaksi', transaksiController.tambahTransaksi);
router.get('/transaksi', transaksiController.ambilSemuaTransaksi);
router.delete('/transaksi/:id', transaksiController.hapusTransaksi);

module.exports = router;