// controllers/authController.js
const { Pool } = require('pg');

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

// 1. LOGIKA REGISTER (Daftar Akun)
const register = async (req, res) => {
  const { nama, email, password } = req.body;
  try {
    // Cek apakah email sudah terdaftar
    const cekEmail = await pool.query('SELECT * FROM pengguna WHERE email = $1', [email]);
    if (cekEmail.rows.length > 0) {
      return res.status(400).json({ status: 'error', message: 'Email sudah terdaftar!' });
    }

    // Simpan pengguna baru ke database
    // Catatan MVP: Untuk tahap awal, kita simpan plain-text dulu. Jika ingin lebih aman, nanti bisa pakai bcrypt.
    const query = `
      INSERT INTO pengguna (nama, email, password)
      VALUES ($1, $2, $3)
      RETURNING id, nama, email;
    `;
    const result = await pool.query(query, [nama, email, password]);

    res.status(201).json({
      status: 'success',
      message: 'Akun berhasil dibuat!',
      data: result.rows[0]
    });
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};

// 2. LOGIKA LOGIN (Masuk Akun)
const login = async (req, res) => {
  const { email, password } = req.body;
  try {
    // Cari pengguna berdasarkan email
    const result = await pool.query('SELECT * FROM pengguna WHERE email = $1', [email]);
    if (result.rows.length === 0) {
      return res.status(404).json({ status: 'error', message: 'Email tidak ditemukan!' });
    }

    const user = result.rows[0];

    // Cocokkan password
    if (user.password !== password) {
      return res.status(401).json({ status: 'error', message: 'Password salah!' });
    }

    res.status(200).json({
      status: 'success',
      message: 'Login berhasil!',
      data: {
        id: user.id,
        nama: user.nama,
        email: user.email
      }
    });
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};

module.exports = { register, login };