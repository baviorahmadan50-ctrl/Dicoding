const axios = require('axios');

// URL API AI dari tim Python
const AI_SERVICE_URL = 'http://localhost:8000/predict';

// Logika untuk mengirim data finansial ke FastAPI Python
const prosesAnalisisKeuangan = async (req, res) => {
  try {
    const profilFinansial = req.body;
    console.log("Meneruskan data profil finansial ke API AI FastAPI...");
    
    // Menembak data ke FastAPI menggunakan axios
    const responseDariAI = await axios.post(AI_SERVICE_URL, profilFinansial);
    const hasilPrediksiAI = responseDariAI.data;

    return res.json({
      success: true,
      message: 'Analisis kecerdasan buatan berhasil didapatkan.',
      data: hasilPrediksiAI
    });

  } catch (error) {
    console.error('Error Integrasi AI di Controller:', error.message);
    return res.status(502).json({
      success: false,
      message: 'Gagal terhubung ke service Virtual Pet AI. Pastikan server Python (FastAPI) aktif di port 8000.'
    });
  }
};

// Ekspor fungsi agar bisa dibaca oleh file routes
module.exports = {
  prosesAnalisisKeuangan
};