// controllers/transaksiController.js
const { Pool } = require('pg');

// Gunakan konfigurasi pool yang sama dengan server.js
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

// 1. TAMBAH TRANSAKSI BARU (Create)
const tambahTransaksi = async (req, res) => {
  const { deskripsi, jumlah, tipe } = req.body;
  try {
    const query = `
      INSERT INTO transaksi (deskripsi, jumlah, tipe)
      VALUES ($1, $2, $3)
      RETURNING *;
    `;
    const result = await pool.query(query, [deskripsi, jumlah, tipe]);
    res.status(201).json({
      status: 'success',
      data: result.rows[0]
    });
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};

// 2. AMBIL SEMUA DATA TRANSAKSI (Read)
const ambilSemuaTransaksi = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM transaksi ORDER BY tanggal DESC;');
    res.status(200).json({
      status: 'success',
      data: result.rows
    });
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};

// 3. HAPUS TRANSAKSI (Delete)
const hapusTransaksi = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM transaksi WHERE id = $1 RETURNING *;', [id]);
    if (result.rowCount === 0) {
      return res.status(404).json({ status: 'error', message: 'Transaksi tidak ditemukan' });
    }
    res.status(200).json({
      status: 'success',
      message: `Transaksi dengan ID ${id} berhasil dihapus.`
    });
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};

module.exports = {
  tambahTransaksi,
  ambilSemuaTransaksi,
  hapusTransaksi
};