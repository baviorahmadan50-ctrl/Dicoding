import React from 'react';
import { Wallet, Landmark } from 'lucide-react';

const WalletIntegration = () => {
  const eWallets = ['DANA', 'OVO', 'GoPay', 'LinkAja', 'ShopeePay'];
  const mBanking = ['BRImo', 'Livin by Mandiri', 'BCA Mobile', 'BSI Mobile'];

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h2 className="text-lg font-bold mb-4 flex items-center gap-2"><Wallet className="text-blue-500" /> Dompet Digital & Bank</h2>
      
      <div className="mb-4">
        <h3 className="text-sm font-semibold text-gray-500 mb-2">E-Wallet Terhubung</h3>
        <div className="flex flex-wrap gap-2">
          {eWallets.map((wallet) => (
            <span key={wallet} className="px-3 py-1 bg-blue-50 text-blue-700 text-xs font-bold rounded-full border border-blue-200">
              {wallet}
            </span>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-gray-500 mb-2">Mobile Banking Terhubung</h3>
        <div className="flex flex-wrap gap-2">
          {mBanking.map((bank) => (
            <span key={bank} className="px-3 py-1 bg-orange-50 text-orange-700 text-xs font-bold rounded-full border border-orange-200">
              {bank}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default WalletIntegration;