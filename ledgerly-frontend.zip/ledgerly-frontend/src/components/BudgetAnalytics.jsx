import React, { useState } from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const BudgetAnalytics = () => {
  const [totalIncome, setTotalIncome] = useState(); 

  
  const fixedExpense = totalIncome * 0.50; 
  const variableExpense = totalIncome * 0.30; 
  const emergencyFund = totalIncome * 0.20; 

  const data = [
    { name: 'Pengeluaran Tetap (50%)', value: fixedExpense, color: '#3B82F6' },
    { name: 'Tak Tetap/Hiburan (30%)', value: variableExpense, color: '#F59E0B' },
    { name: 'Dana Darurat/Tabungan (20%)', value: emergencyFund, color: '#10B981' },
  ];

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h2 className="text-lg font-bold mb-4">Analisis & Alokasi Dana</h2>
      
      <div className="mb-4">
        <label className="block text-sm text-gray-600">Simulasi Total Pendapatan Bulan Ini (Rp)</label>
        <input 
          type="number" 
          value={totalIncome} 
          onChange={(e) => setTotalIncome(Number(e.target.value))}
          className="w-full mt-1 border p-2 rounded focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div className="grid grid-cols-3 gap-2 text-center mb-6">
        <div className="p-2 bg-blue-50 rounded">
          <p className="text-xs text-blue-600 font-bold">Tetap</p>
          <p className="font-semibold">Rp {(fixedExpense).toLocaleString('id-ID')}</p>
        </div>
        <div className="p-2 bg-yellow-50 rounded">
          <p className="text-xs text-yellow-600 font-bold">Tak Tetap</p>
          <p className="font-semibold">Rp {(variableExpense).toLocaleString('id-ID')}</p>
        </div>
        <div className="p-2 bg-green-50 rounded">
          <p className="text-xs text-green-600 font-bold">Darurat</p>
          <p className="font-semibold">Rp {(emergencyFund).toLocaleString('id-ID')}</p>
        </div>
      </div>

      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip formatter={(value) => `Rp ${value.toLocaleString('id-ID')}`} />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default BudgetAnalytics;