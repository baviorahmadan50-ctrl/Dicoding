import React, { useState } from 'react';
import { Mail } from 'lucide-react';

const NotificationSettings = () => {
  const [settings, setSettings] = useState({
    income: true,
    expense: false,
    critical: true,
  });

  const toggleSetting = (key) => {
    setSettings({ ...settings, [key]: !settings[key] });
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h2 className="text-lg font-bold mb-4 flex items-center gap-2"><Mail className="text-blue-500" /> Preferensi Email</h2>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-semibold">Email Dana Masuk</p>
            <p className="text-xs text-gray-500">Terima struk saat ada pendapatan.</p>
          </div>
          <input type="checkbox" checked={settings.income} onChange={() => toggleSetting('income')} className="w-5 h-5 text-blue-600" />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <p className="font-semibold">Email Dana Keluar</p>
            <p className="text-xs text-gray-500">Notifikasi harian untuk pengeluaran.</p>
          </div>
          <input type="checkbox" checked={settings.expense} onChange={() => toggleSetting('expense')} className="w-5 h-5 text-blue-600" />
        </div>

        <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-100">
          <div>
            <p className="font-bold text-red-700">Peringatan Dana Krisis (Overbudget)</p>
            <p className="text-xs text-red-600">Peringatan otomatis oleh AI Ledgerly.</p>
          </div>
          <input type="checkbox" checked={settings.critical} onChange={() => toggleSetting('critical')} className="w-5 h-5 text-red-600" />
        </div>
      </div>
    </div>
  );
};

export default NotificationSettings;