import React from 'react';

const VirtualPet = ({ status }) => {
  let petImage = '';
  let statusMessage = '';
  let bgColor = '';

  switch (status) {
    case 'critical':
      petImage = '/assets/pet-sad.png';
      statusMessage = 'Gawat! Pengeluaranmu hampir melebihi batas!';
      bgColor = 'bg-red-100 border-red-400 text-red-700';
      break;
    case 'warning':
      petImage = '/assets/pet-warning.png';
      statusMessage = 'Hati-hati, perhatikan pengeluaran hiburanmu.';
      bgColor = 'bg-yellow-100 border-yellow-400 text-yellow-700';
      break;
    case 'healthy':
    default:
      petImage = '/assets/pet-happy.png';
      statusMessage = 'Keuanganmu sangat sehat! Teruskan!';
      bgColor = 'bg-green-100 border-green-400 text-green-700';
      break;
  }

  return (
    <div className="text-center w-full">
      <div className="w-48 h-48 mx-auto mb-4 bg-gray-200 rounded-full flex items-center justify-center overflow-hidden border-4 border-gray-300">
        <span className="text-gray-500 text-sm">(Gambar Pet: {status})</span>
      </div>
      
      <div className={`p-3 rounded border ${bgColor}`}>
        <p className="font-medium">{statusMessage}</p>
      </div>
    </div>
  );
};

export default VirtualPet;