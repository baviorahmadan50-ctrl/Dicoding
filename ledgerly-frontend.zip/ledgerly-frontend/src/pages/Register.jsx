import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Mail, Lock, User, Eye, EyeOff } from 'lucide-react';
import logoImg from './logo.png'; // Pastikan path logo sesuai
import './Login.css'; // Menggunakan CSS yang sama agar konsisten

const Register = () => {
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleRegister = (e) => {
    e.preventDefault();
    // Simpan data pendaftaran sederhana
    localStorage.setItem('userLoginData', JSON.stringify({
      email: formData.email,
      password: formData.password,
      fullName: formData.name
    }));
    alert('Registrasi berhasil! Silakan login.');
    navigate('/login');
  };

  return (
    <div className="auth-container">
      <div className="bg-glow-1"></div>
      <div className="bg-glow-2"></div>

      <div className="auth-card">
        <div className="auth-card-header">
          <div className="brand-logo-container">
            <img src={logoImg} alt="Ledgerly Logo" className="brand-custom-logo" />
          </div>
          <h1 className="brand-title">Daftar Ledgerly</h1>
          <p className="brand-subtitle">
            Mulai kendalikan keuanganmu sekarang bersama asisten AI.
          </p>
        </div>

        <form onSubmit={handleRegister} className="auth-form">
          {/* Input Nama Lengkap */}
          <div className="form-group">
            <label className="form-label" htmlFor="name">Nama Lengkap</label>
            <div className="input-wrapper">
              <User className="input-icon-left" />
              <input 
                id="name"
                type="text" 
                className="form-input" 
                placeholder="Masukkan nama lengkap"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                required
              />
            </div>
          </div>

          {/* Input Email */}
          <div className="form-group">
            <label className="form-label" htmlFor="email">Email</label>
            <div className="input-wrapper">
              <Mail className="input-icon-left" />
              <input 
                id="email"
                type="email" 
                className="form-input" 
                placeholder="nama@email.com"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                required
              />
            </div>
          </div>

          {/* Input Password */}
          <div className="form-group">
            <label className="form-label" htmlFor="password">Kata Sandi</label>
            <div className="input-wrapper">
              <Lock className="input-icon-left" />
              <input 
                id="password"
                type={showPassword ? "text" : "password"} 
                className="form-input" 
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                required
              />
              <button 
                type="button"
                className="password-toggle-btn"
                onClick={() => setShowPassword(!showPassword)}
                tabIndex="-1"
              >
                {showPassword ? <EyeOff className="toggle-icon" /> : <Eye className="toggle-icon" />}
              </button>
            </div>
          </div>

          <button type="submit" className="btn-submit">
            Daftar Sekarang
          </button>
        </form>

        <div className="auth-card-footer">
          <p>
            Sudah punya akun?{' '}
            <Link to="/login" className="register-link">
              Masuk ke Akun
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;