import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import { Sparkles, BarChart2, Eye, EyeOff, Loader2, Mail, Lock } from 'lucide-react';
import logoImg from './logo.png';
import './Login.css';

const Login = () => {
const [email, setEmail] = useState('');
const [password, setPassword] = useState('');
const [showPassword, setShowPassword] = useState(false);
const [isLoading, setIsLoading] = useState(false);

const navigate = useNavigate();

const handleLogin = async (e) => {
e.preventDefault();
setIsLoading(true);


try {
  const response = await axios.post(
    'http://localhost:5000/api/auth/login',
    {
      email,
      password
    }
  );

  const user = response.data.data;

  const dataPenggunaLogin = {
    firstName: user.nama,
    fullName: user.nama,
    initials: user.nama.charAt(0).toUpperCase(),
    email: user.email,
    role: 'Pengguna',
    status: 'Aktif'
  };

  localStorage.setItem(
    'userLoginData',
    JSON.stringify(dataPenggunaLogin)
  );

  navigate('/dashboard');

} catch (error) {
  if (error.response) {
    alert(error.response.data.message);
  } else {
    alert('Tidak dapat terhubung ke server backend');
  }
} finally {
  setIsLoading(false);
}


};

return ( <div className="auth-container"> <div className="bg-glow-1"></div> <div className="bg-glow-2"></div>


  <div className="auth-card">
    <div className="auth-card-header">
      <div className="brand-logo-container">
        <img
          src={logoImg}
          alt="Ledgerly Logo"
          className="brand-custom-logo"
        />
      </div>

      <h1 className="brand-title">Ledgerly</h1>

      <p className="brand-subtitle">
        Kendalikan keuanganmu bersama asisten AI & virtual pet interaktif.
      </p>
    </div>

    <form onSubmit={handleLogin} className="auth-form">
      <div className="form-group">
        <label className="form-label" htmlFor="email">
          Email
        </label>

        <div className="input-wrapper">
          <Mail className="input-icon-left" />

          <input
            id="email"
            type="email"
            className="form-input"
            placeholder="nama@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
      </div>

      <div className="form-group">
        <label className="form-label" htmlFor="password">
          Kata Sandi
        </label>

        <div className="input-wrapper">
          <Lock className="input-icon-left" />

          <input
            id="password"
            type={showPassword ? 'text' : 'password'}
            className="form-input"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button
            type="button"
            className="password-toggle-btn"
            onClick={() => setShowPassword(!showPassword)}
            tabIndex="-1"
          >
            {showPassword ? (
              <EyeOff className="toggle-icon" />
            ) : (
              <Eye className="toggle-icon" />
            )}
          </button>
        </div>
      </div>

      <button
        type="submit"
        className="btn-submit"
        disabled={isLoading}
      >
        {isLoading ? (
          <>
            <Loader2 className="spinner-icon" />
            <span>Memverifikasi...</span>
          </>
        ) : (
          'Masuk ke Akun'
        )}
      </button>
    </form>

    <div className="auth-card-footer">
      <p>
        Belum punya akun?{' '}
        <Link to="/register" className="register-link">
          Daftar sekarang
        </Link>
      </p>
    </div>

    <div className="mini-features-grid">
      <div className="mini-feature">
        <Sparkles className="feat-icon text-amber-600" />
        <span>AI Prediction</span>
      </div>

      <div className="mini-feature">
        <img
          src={logoImg}
          alt="Pet"
          className="feat-icon-mini"
        />
        <span>Virtual Pet</span>
      </div>

      <div className="mini-feature">
        <BarChart2 className="feat-icon text-emerald-600" />
        <span>Analytics</span>
      </div>
    </div>
  </div>
</div>


);
};

export default Login;
