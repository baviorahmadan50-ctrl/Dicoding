import React from 'react';
import { Link } from 'react-router-dom';
import { Cat, Sparkles, BarChart3, ShieldCheck, ArrowRight } from 'lucide-react';
import './Welcome.css';

const Welcome = () => {
  return (
    <div className="welcome-wrapper">
      
      {/* 1. NAVBAR / HEADER */}
      <nav className="welcome-nav max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-[#a67c52] rounded-xl flex items-center justify-center shadow-lg">
            <span className="text-white font-black text-xl">L</span>
          </div>
          <span className="text-2xl font-black text-[#4a331c] tracking-tight">Ledgerly</span>
        </div>
        
        <Link to="/login" className="text-[#a67c52] font-bold hover:text-[#8c6239] transition">
          Masuk Akun
        </Link>
      </nav>

      {/* 2. BAGIAN HERO (TEKS UTAMA) */}
      <main className="welcome-hero">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#fceee3] text-[#a67c52] font-bold text-xs uppercase tracking-widest mb-6">
          <Sparkles className="w-4 h-4" /> Manajemen Keuangan Masa Depan
        </div>
        
        <h1 className="hero-title">
          Kendalikan Keuanganmu Bersama <span>AI Virtual Pet</span>
        </h1>
        
        <p className="hero-subtitle">
          Ledgerly bukan sekadar pencatat keuangan biasa. Kami memadukan kecerdasan buatan (AI) 
          dan peliharaan virtual yang lucu untuk membuatmu lebih hemat, cerdas, dan disiplin.
        </p>

        {/* TOMBOL PANAH MENUJU LOGIN */}
        <Link to="/login" className="btn-enter-app">
          Mulai Petualanganmu Sekarang
          <ArrowRight className="w-6 h-6 arrow-icon" strokeWidth={3} />
        </Link>

        {/* 3. BUBBLE INFORMASI (MELAYANG) */}
        <div className="bubbles-container">
          
          {/* Bubble 1 */}
          <div className="info-bubble">
            <div className="bubble-icon-wrapper">
              <Sparkles className="w-7 h-7" />
            </div>
            <h3 className="bubble-title">AI Prediksi Boros</h3>
            <p className="bubble-desc">
              Algoritma kami menganalisis kebiasaanmu dan memberi peringatan otomatis sebelum kamu kehabisan uang.
            </p>
          </div>

          {/* Bubble 2 */}
          <div className="info-bubble">
            <div className="bubble-icon-wrapper">
              <Cat className="w-7 h-7" />
            </div>
            <h3 className="bubble-title">Peliharaan Kibi</h3>
            <p className="bubble-desc">
              Kesehatan Kibi si kucing virtual mencerminkan kondisi finansialmu. Hemat pangkal bahagia!
            </p>
          </div>

          {/* Bubble 3 */}
          <div className="info-bubble">
            <div className="bubble-icon-wrapper">
              <BarChart3 className="w-7 h-7" />
            </div>
            <h3 className="bubble-title">Analitik Cerdas</h3>
            <p className="bubble-desc">
              Laporan visual interaktif yang membantu kamu memahami kemana perginya setiap rupiah bulan ini.
            </p>
          </div>

        </div>
      </main>

    </div>
  );
};

export default Welcome;