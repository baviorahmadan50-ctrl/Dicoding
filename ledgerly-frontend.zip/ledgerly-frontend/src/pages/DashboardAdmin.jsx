import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, Users, Receipt, Cpu, BarChart3, 
  Bell, Settings, LogOut, RefreshCw, Eye, CheckCircle2, 
  Download, Plus, Search, Check, Wallet, Ban
} from 'lucide-react';
import './DashboardAdmin.css';

const DashboardAdmin = () => {
  const navigate = useNavigate();
  const [activeMenu, setActiveMenu] = useState('Dashboard');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // ==========================================
  // 1. STATE: DATA ADMIN & DATA USER (SINKRONISASI)
  // ==========================================
  const [adminData, setAdminData] = useState({
    fullName: 'Admin Ledgerly',
    initials: 'AD',
    role: 'Super admin'
  });

  // State untuk menampung data riil dari sisi User
  const [realUserData, setRealUserData] = useState(null);

  // Fungsi untuk menarik data User secara langsung (Berkesinambungan)
  const syncWithUserData = () => {
    const savedAppData = localStorage.getItem('ledgerlyAppData');
    if (savedAppData) {
      const parsedData = JSON.parse(savedAppData);
      setRealUserData(parsedData);
      return parsedData;
    }
    return null;
  };

  useEffect(() => {
    syncWithUserData();
  }, []);

  // Menghitung data dinamis berdasarkan data User yang masuk
  const userTxCount = realUserData ? realUserData.transactions.length : 0;
  const userFullName = realUserData ? realUserData.profile.fullName : 'Merischa Theresia H.';
  const userEmail = realUserData ? realUserData.profile.email : 'merischa@unib.ac.id';
  const userJob = realUserData ? realUserData.profile.job : 'Mahasiswa Informatika';
  const userInitials = realUserData ? realUserData.profile.initials : 'MH';

  // Base statistik + Data riil User
  const [stats, setStats] = useState({
    totalUsers: '1.223',
    activeUsers: '342',
    totalTransactions: 28296, // Base angka
    aiWarnings: '98'
  });

  const handleRefresh = () => {
    setIsRefreshing(true);
    // Saat di-refresh, tarik data user terbaru
    syncWithUserData();
    setTimeout(() => {
      setIsRefreshing(false);
    }, 800);
  };

  const handleLogout = () => {
    navigate('/login');
  };

  // ==========================================
  // VIEW 1: DASHBOARD UTAMA
  // ==========================================
  const ViewDashboard = () => {
    // Tanggal hari ini
    const today = new Date().toLocaleDateString('id-ID', { day:'numeric', month:'long', year:'numeric' });
    
    // Total transaksi dinamis: Base 28.296 + jumlah transaksi user yang sebenarnya
    const dynamicTotalTx = (stats.totalTransactions + userTxCount).toLocaleString('id-ID');

    return (
      <div className="animate-fadeIn">
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem'}}>
          <div>
            <h2 style={{fontSize: '1.8rem', fontWeight: '900', color: '#1e293b', margin: '0 0 0.25rem 0'}}>Dashboard admin</h2>
            <p style={{color: '#64748b', margin: 0}}>Ringkasan sistem Ledgerly — {today}</p>
          </div>
          <button style={{display:'flex', alignItems:'center', gap:'0.5rem', padding:'0.5rem 1rem', background:'white', border:'1px solid #e2e8f0', borderRadius:'8px', cursor:'pointer', fontWeight:'700', color:'#334155'}} onClick={handleRefresh} disabled={isRefreshing}>
            <RefreshCw size={16} className={isRefreshing ? "animate-spin" : ""} /> 
            {isRefreshing ? 'Memperbarui...' : 'Refresh data'}
          </button>
        </div>

        {/* 4 KARTU STATISTIK (SINKRON DENGAN DATA USER) */}
        <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1.5rem', marginBottom: '1.5rem'}}>
          <div style={{background: 'white', padding: '1.5rem', borderRadius: '1rem', border: '1px solid #e2e8f0', borderTop: '4px solid #34d399', textAlign:'center'}}>
            <p style={{fontSize: '0.75rem', fontWeight: '800', color: '#64748b', margin: '0 0 0.5rem 0'}}>TOTAL PENGGUNA</p>
            <h3 style={{fontSize: '2rem', fontWeight: '900', color: '#1e293b', margin: '0 0 0.5rem 0'}}>{stats.totalUsers}</h3>
            <span style={{fontSize: '0.7rem', background: '#d1fae5', color: '#059669', padding: '0.25rem 0.75rem', borderRadius: '20px', fontWeight: '800'}}>↑ +47 MINGGU INI</span>
          </div>
          <div style={{background: 'white', padding: '1.5rem', borderRadius: '1rem', border: '1px solid #e2e8f0', borderTop: '4px solid #34d399', textAlign:'center'}}>
            <p style={{fontSize: '0.75rem', fontWeight: '800', color: '#64748b', margin: '0 0 0.5rem 0'}}>PENGGUNA AKTIF</p>
            <h3 style={{fontSize: '2rem', fontWeight: '900', color: '#1e293b', margin: '0 0 0.5rem 0'}}>{stats.activeUsers}</h3>
            <span style={{fontSize: '0.7rem', background: '#d1fae5', color: '#059669', padding: '0.25rem 0.75rem', borderRadius: '20px', fontWeight: '800'}}>↑ +24% DARI KEMARIN</span>
          </div>
          <div style={{background: 'white', padding: '1.5rem', borderRadius: '1rem', border: '1px solid #e2e8f0', borderTop: '4px solid #94a3b8', textAlign:'center'}}>
            <p style={{fontSize: '0.75rem', fontWeight: '800', color: '#64748b', margin: '0 0 0.5rem 0'}}>TOTAL TRANSAKSI</p>
            {/* ANGKANYA BERUBAH JIKA USER NAMBAH TRANSAKSI */}
            <h3 style={{fontSize: '2rem', fontWeight: '900', color: '#1e293b', margin: '0 0 0.5rem 0'}}>{dynamicTotalTx}</h3>
            <span style={{fontSize: '0.75rem', fontWeight: '700', color: '#64748b'}}>Sepanjang masa</span>
          </div>
          <div style={{background: '#fef2f2', padding: '1.5rem', borderRadius: '1rem', border: '1px solid #fecaca', borderTop: '4px solid #f87171', textAlign:'center'}}>
            <p style={{fontSize: '0.75rem', fontWeight: '800', color: '#dc2626', margin: '0 0 0.5rem 0'}}>PERINGATAN AI</p>
            <h3 style={{fontSize: '2rem', fontWeight: '900', color: '#dc2626', margin: '0 0 0.5rem 0'}}>{stats.aiWarnings}</h3>
            <span style={{fontSize: '0.7rem', background: '#fee2e2', color: '#b91c1c', padding: '0.25rem 0.75rem', borderRadius: '20px', fontWeight: '800'}}>↑ +12 HARI INI</span>
          </div>
        </div>

        {/* AREA DIAGRAM */}
        <div style={{display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '1.5rem'}}>
          
          {/* DIAGRAM BATANG (KIRI) */}
          <div style={{background: 'white', padding: '1.5rem', borderRadius: '1rem', border: '1px solid #e2e8f0'}}>
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'2rem'}}>
              <h3 style={{fontWeight:'900', fontSize:'1.1rem', color:'#1e293b', margin:0}}>Registrasi pengguna baru</h3>
              <span style={{fontSize:'0.75rem', color:'#64748b', fontWeight:'700'}}>7 hari terakhir</span>
            </div>
            <div style={{display:'flex', alignItems:'flex-end', justifyContent:'space-around', height:'160px', borderBottom:'1px solid #e2e8f0', paddingBottom:'0.5rem'}}>
              <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:'0.5rem'}}><div style={{width:'30px', height:'40px', background:'#e2d8ce', borderRadius:'4px 4px 0 0'}}></div><span style={{fontSize:'0.75rem', fontWeight:'700', color:'#64748b'}}>Sel</span></div>
              <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:'0.5rem'}}><div style={{width:'30px', height:'65px', background:'#e2d8ce', borderRadius:'4px 4px 0 0'}}></div><span style={{fontSize:'0.75rem', fontWeight:'700', color:'#64748b'}}>Rab</span></div>
              <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:'0.5rem'}}><div style={{width:'30px', height:'55px', background:'#e2d8ce', borderRadius:'4px 4px 0 0'}}></div><span style={{fontSize:'0.75rem', fontWeight:'700', color:'#64748b'}}>Kam</span></div>
              <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:'0.5rem'}}><div style={{width:'30px', height:'110px', background:'#a67c52', borderRadius:'4px 4px 0 0'}}></div><span style={{fontSize:'0.75rem', fontWeight:'700', color:'#64748b'}}>Jum</span></div>
              <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:'0.5rem'}}><div style={{width:'30px', height:'45px', background:'#a67c52', borderRadius:'4px 4px 0 0'}}></div><span style={{fontSize:'0.75rem', fontWeight:'700', color:'#64748b'}}>Sab</span></div>
              <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:'0.5rem'}}><div style={{width:'30px', height:'35px', background:'#a67c52', borderRadius:'4px 4px 0 0'}}></div><span style={{fontSize:'0.75rem', fontWeight:'700', color:'#64748b'}}>Min</span></div>
              <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:'0.5rem'}}><div style={{width:'30px', height:'95px', background:'#a67c52', borderRadius:'4px 4px 0 0'}}></div><span style={{fontSize:'0.75rem', fontWeight:'700', color:'#64748b'}}>Sen</span></div>
            </div>
          </div>

          {/* DIAGRAM LINGKARAN & STATUS AI (KANAN) */}
          <div style={{background: 'white', padding: '1.5rem', borderRadius: '1rem', border: '1px solid #e2e8f0', display:'flex', flexDirection:'column', justifyContent:'space-between'}}>
            <h3 style={{fontWeight:'900', fontSize:'1.1rem', color:'#1e293b', margin:0, marginBottom:'1rem'}}>Status Model AI</h3>
            
            <div style={{display:'flex', alignItems:'center', gap:'2rem', marginBottom:'1.5rem'}}>
              <div style={{width:'90px', height:'90px'}}>
                <svg viewBox="0 0 36 36" style={{transform: 'rotate(-90deg)', width:'100%', height:'100%'}}>
                  <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#f1f5f9" strokeWidth="6" />
                  <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#a67c52" strokeWidth="6" strokeDasharray="82, 100" />
                  <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#10b981" strokeWidth="6" strokeDasharray="18, 100" strokeDashoffset="-82" />
                </svg>
              </div>
              <div style={{display:'flex', flexDirection:'column', gap:'0.75rem'}}>
                <div style={{display:'flex', alignItems:'center', gap:'0.5rem'}}><span style={{width:'12px',height:'12px',background:'#a67c52',borderRadius:'50%'}}></span><span style={{fontSize:'0.85rem',fontWeight:'800', color:'#334155'}}>Akurasi 82%</span></div>
                <div style={{display:'flex', alignItems:'center', gap:'0.5rem'}}><span style={{width:'12px',height:'12px',background:'#10b981',borderRadius:'50%'}}></span><span style={{fontSize:'0.85rem',fontWeight:'800', color:'#334155'}}>True Pos 71%</span></div>
              </div>
            </div>
            <div style={{background:'#d1fae5', color:'#059669', padding:'0.75rem 1rem', borderRadius:'0.5rem', display:'flex', alignItems:'center', gap:'0.5rem', fontSize:'0.85rem', fontWeight:'800'}}>
              <CheckCircle2 size={18} /> Model v2.1 Normal
            </div>
          </div>
        </div>
      </div>
    );
  };

  // ==========================================
  // VIEW 2: MANAJEMEN PENGGUNA (TERHUBUNG KE USER)
  // ==========================================
  const ViewManajemenPengguna = () => (
    <div className="animate-fadeIn">
      <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem'}}>
        <div>
          <h2 style={{fontSize: '1.8rem', fontWeight: '900', color: '#1e293b', margin: '0 0 0.25rem 0'}}>Manajemen pengguna</h2>
          <p style={{color: '#64748b', margin: 0}}>3 pengguna terdaftar · Terhubung dengan sistem utama</p>
        </div>
        <div style={{display:'flex', gap:'1rem'}}>
          <button style={{display:'flex', alignItems:'center', gap:'0.5rem', padding:'0.5rem 1rem', background:'white', border:'1px solid #e2e8f0', borderRadius:'8px', cursor:'pointer', fontWeight:'700', color:'#334155'}}><Download size={16}/> Ekspor CSV</button>
          <button style={{display:'flex', alignItems:'center', gap:'0.5rem', padding:'0.5rem 1rem', background:'#a67c52', color:'white', border:'none', borderRadius:'8px', cursor:'pointer', fontWeight:'700'}}><Plus size={16}/> Tambah pengguna</button>
        </div>
      </div>

      <div style={{background: 'white', borderRadius: '1rem', border: '1px solid #e2e8f0', overflow: 'hidden'}}>
        <div style={{padding:'1rem 1.5rem', borderBottom:'1px solid #e2e8f0', display:'flex', gap:'1rem', background:'#f8fafc'}}>
          <div style={{position:'relative', flex:1}}><Search size={16} style={{position:'absolute', left:'1rem', top:'50%', transform:'translateY(-50%)', color:'#94a3b8'}}/><input style={{width:'100%', padding:'0.5rem 1rem 0.5rem 2.5rem', border:'1px solid #cbd5e1', borderRadius:'6px', outline:'none'}} placeholder="Cari nama atau email..." /></div>
          <select style={{padding:'0.5rem 1rem', border:'1px solid #cbd5e1', borderRadius:'6px', background:'white', outline:'none', cursor:'pointer'}}><option>Semua status</option><option>Aktif</option><option>Suspend</option></select>
        </div>

        <table style={{width: '100%', borderCollapse: 'collapse', textAlign: 'left'}}>
          <thead>
            <tr style={{background: '#f1f5f9', color: '#64748b', fontSize: '0.75rem', textTransform: 'uppercase'}}>
              <th style={{padding: '1rem 1.5rem'}}>Pengguna / Profil</th>
              <th style={{padding: '1rem 1.5rem'}}>ID / NPM</th>
              <th style={{padding: '1rem 1.5rem'}}>Bergabung</th>
              <th style={{padding: '1rem 1.5rem'}}>Transaksi</th>
              <th style={{padding: '1rem 1.5rem'}}>Status</th>
              <th style={{padding: '1rem 1.5rem'}}>Aksi</th>
            </tr>
          </thead>
          <tbody>
            
            {/* INI ADALAH BARIS DATA USER YANG REAL-TIME TERHUBUNG */}
            <tr style={{borderBottom: '1px solid #e2e8f0', background: 'white'}}>
              <td style={{padding: '1rem 1.5rem', display:'flex', alignItems:'center', gap:'1rem'}}>
                <div style={{width:'40px', height:'40px', borderRadius:'50%', background:'#a67c52', color:'white', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:'bold'}}>{userInitials}</div>
                <div>
                  <p style={{margin: 0, fontWeight: '800', color: '#1e293b'}}>{userFullName}</p>
                  <p style={{margin: 0, fontSize: '0.75rem', color: '#64748b'}}>{userJob}</p>
                  <p style={{margin: 0, fontSize: '0.75rem', color: '#94a3b8'}}>{userEmail}</p>
                </div>
              </td>
              <td style={{padding: '1rem 1.5rem', fontSize: '0.85rem', fontWeight:'700', color:'#475569'}}>G1A023071</td>
              <td style={{padding: '1rem 1.5rem', fontSize: '0.85rem', color:'#475569'}}>10 Jan 2026</td>
              {/* Jumlah Transaksi Real-time */}
              <td style={{padding: '1rem 1.5rem', fontWeight: '900', color:'#10b981', fontSize:'1.1rem'}}>{userTxCount}</td>
              <td style={{padding: '1rem 1.5rem'}}>
                <span style={{padding:'0.25rem 0.75rem', borderRadius:'20px', fontSize:'0.75rem', fontWeight:'800', background: '#d1fae5', color: '#059669'}}>Aktif</span>
              </td>
              <td style={{padding: '1rem 1.5rem'}}>
                <div style={{display:'flex', gap:'0.5rem'}}>
                  <button style={{padding:'0.4rem', background:'white', border:'1px solid #cbd5e1', borderRadius:'6px', cursor:'pointer', color:'#3b82f6'}} title="Lihat Detail"><Eye size={16}/></button>
                  <button style={{padding:'0.4rem', background:'white', border:'1px solid #cbd5e1', borderRadius:'6px', cursor:'pointer', color: '#ef4444'}} title="Suspend Akun"><Ban size={16}/></button>
                </div>
              </td>
            </tr>

            {/* Mock Data Tambahan agar tabel tidak kosong */}
            <tr style={{borderBottom: '1px solid #e2e8f0', background: 'white'}}>
              <td style={{padding: '1rem 1.5rem', display:'flex', alignItems:'center', gap:'1rem'}}>
                <div style={{width:'40px', height:'40px', borderRadius:'50%', background:'#a67c52', color:'white', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:'bold'}}>BS</div>
                <div>
                  <p style={{margin: 0, fontWeight: '800', color: '#1e293b'}}>Budi Santoso</p>
                  <p style={{margin: 0, fontSize: '0.75rem', color: '#64748b'}}>Karyawan Swasta</p>
                  <p style={{margin: 0, fontSize: '0.75rem', color: '#94a3b8'}}>budi.s@gmail.com</p>
                </div>
              </td>
              <td style={{padding: '1rem 1.5rem', fontSize: '0.85rem', fontWeight:'700', color:'#475569'}}>USR002</td>
              <td style={{padding: '1rem 1.5rem', fontSize: '0.85rem', color:'#475569'}}>15 Mar 2026</td>
              <td style={{padding: '1rem 1.5rem', fontWeight: '900', color:'#1e293b'}}>89</td>
              <td style={{padding: '1rem 1.5rem'}}><span style={{padding:'0.25rem 0.75rem', borderRadius:'20px', fontSize:'0.75rem', fontWeight:'800', background: '#d1fae5', color: '#059669'}}>Aktif</span></td>
              <td style={{padding: '1rem 1.5rem'}}><div style={{display:'flex', gap:'0.5rem'}}><button style={{padding:'0.4rem', background:'white', border:'1px solid #cbd5e1', borderRadius:'6px', cursor:'pointer', color:'#3b82f6'}}><Eye size={16}/></button><button style={{padding:'0.4rem', background:'white', border:'1px solid #cbd5e1', borderRadius:'6px', cursor:'pointer', color: '#ef4444'}}><Ban size={16}/></button></div></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );

  const ViewLainnya = ({ judul }) => (
    <div className="animate-fadeIn" style={{background: 'white', padding: '4rem 2rem', borderRadius: '1rem', border: '1px solid #e2e8f0', textAlign: 'center'}}>
      <Cpu size={48} color="#cbd5e1" style={{margin:'0 auto 1rem'}}/>
      <h2 style={{fontSize:'1.5rem', fontWeight:'900', color:'#1e293b', marginBottom:'0.5rem'}}>Modul {judul}</h2>
      <p style={{color:'#64748b'}}>Halaman sedang dalam tahap perancangan fungsionalitas admin.</p>
    </div>
  );

  const renderContent = () => {
    switch(activeMenu) {
      case 'Dashboard': return <ViewDashboard />;
      case 'Manajemen pengguna': return <ViewManajemenPengguna />;
      case 'Data transaksi': return <ViewLainnya judul="Data Transaksi" />;
      case 'Model AI': return <ViewLainnya judul="Model AI" />;
      default: return <ViewDashboard />;
    }
  };

  return (
    <div style={{display: 'flex', minHeight: '100vh', background: '#f8fafc', fontFamily: "'Inter', sans-serif"}}>
      
      {/* SIDEBAR ADMIN */}
      <aside style={{width: '260px', background: '#5c4535', color: 'white', display: 'flex', flexDirection: 'column'}}>
        <div style={{padding:'1.5rem'}}>
          <div style={{display:'flex', alignItems:'center', gap:'0.75rem', marginBottom:'0.5rem'}}>
            <div style={{width:'36px', height:'36px', background:'#f8fafc', borderRadius:'8px', display:'flex', alignItems:'center', justifyContent:'center', color:'#5c4535', fontWeight:'900'}}>
              <Wallet size={20} />
            </div>
            <h1 style={{fontSize:'1.35rem', fontWeight:'900', color: 'white', margin:0}}>Ledgerly <span style={{fontSize:'0.55rem', background:'#a67c52', padding:'2px 6px', borderRadius:'10px', textTransform:'uppercase', verticalAlign: 'middle'}}>Admin</span></h1>
          </div>
          <p style={{fontSize:'0.75rem', color:'#d1bfae', marginLeft:'3rem', margin:0}}>Panel administrator</p>
        </div>

        <div style={{flex:1, overflowY:'auto', padding:'0 1rem'}}>
          <div style={{fontSize: '0.7rem', fontWeight: '800', color: '#d1bfae', letterSpacing: '1px', padding: '1rem 1rem 0.5rem', textTransform:'uppercase'}}>Utama</div>
          
          <div onClick={() => setActiveMenu('Dashboard')} style={{padding:'0.75rem 1rem', borderRadius:'8px', cursor:'pointer', display:'flex', alignItems:'center', gap:'0.75rem', fontWeight:'700', fontSize:'0.9rem', color: activeMenu === 'Dashboard' ? '#5c4535' : '#e2d8ce', background: activeMenu === 'Dashboard' ? '#e2d8ce' : 'transparent', transition:'0.2s'}}>
            <LayoutDashboard size={18} /> Dashboard
          </div>
          
          <div onClick={() => setActiveMenu('Manajemen pengguna')} style={{padding:'0.75rem 1rem', borderRadius:'8px', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'space-between', fontWeight:'700', fontSize:'0.9rem', color: activeMenu === 'Manajemen pengguna' ? '#5c4535' : '#e2d8ce', background: activeMenu === 'Manajemen pengguna' ? '#e2d8ce' : 'transparent', transition:'0.2s', marginTop:'0.25rem'}}>
            <div style={{display:'flex', alignItems:'center', gap:'0.75rem'}}><Users size={18} /> Manajemen pengguna</div>
            <span style={{background: activeMenu === 'Manajemen pengguna' ? '#5c4535' : '#a67c52', color:'white', fontSize:'0.65rem', padding:'2px 6px', borderRadius:'10px'}}>3</span>
          </div>

          <div onClick={() => setActiveMenu('Data transaksi')} style={{padding:'0.75rem 1rem', borderRadius:'8px', cursor:'pointer', display:'flex', alignItems:'center', gap:'0.75rem', fontWeight:'700', fontSize:'0.9rem', color: activeMenu === 'Data transaksi' ? '#5c4535' : '#e2d8ce', background: activeMenu === 'Data transaksi' ? '#e2d8ce' : 'transparent', transition:'0.2s', marginTop:'0.25rem'}}>
            <Receipt size={18} /> Data transaksi
          </div>
          
          <div onClick={() => setActiveMenu('Model AI')} style={{padding:'0.75rem 1rem', borderRadius:'8px', cursor:'pointer', display:'flex', alignItems:'center', gap:'0.75rem', fontWeight:'700', fontSize:'0.9rem', color: activeMenu === 'Model AI' ? '#5c4535' : '#e2d8ce', background: activeMenu === 'Model AI' ? '#e2d8ce' : 'transparent', transition:'0.2s', marginTop:'0.25rem'}}>
            <Cpu size={18} /> Model AI
          </div>

          <div style={{fontSize: '0.7rem', fontWeight: '800', color: '#d1bfae', letterSpacing: '1px', padding: '1.5rem 1rem 0.5rem', textTransform:'uppercase'}}>Sistem</div>
          
          <div onClick={() => setActiveMenu('Laporan & analitik')} style={{padding:'0.75rem 1rem', borderRadius:'8px', cursor:'pointer', display:'flex', alignItems:'center', gap:'0.75rem', fontWeight:'700', fontSize:'0.9rem', color: activeMenu === 'Laporan & analitik' ? '#5c4535' : '#e2d8ce', background: activeMenu === 'Laporan & analitik' ? '#e2d8ce' : 'transparent', transition:'0.2s'}}>
            <BarChart3 size={18} /> Laporan & analitik
          </div>
          
          <div onClick={() => setActiveMenu('Log notifikasi')} style={{padding:'0.75rem 1rem', borderRadius:'8px', cursor:'pointer', display:'flex', alignItems:'center', gap:'0.75rem', fontWeight:'700', fontSize:'0.9rem', color: activeMenu === 'Log notifikasi' ? '#5c4535' : '#e2d8ce', background: activeMenu === 'Log notifikasi' ? '#e2d8ce' : 'transparent', transition:'0.2s', marginTop:'0.25rem'}}>
            <Bell size={18} /> Log notifikasi
          </div>
          
          <div onClick={() => setActiveMenu('Pengaturan sistem')} style={{padding:'0.75rem 1rem', borderRadius:'8px', cursor:'pointer', display:'flex', alignItems:'center', gap:'0.75rem', fontWeight:'700', fontSize:'0.9rem', color: activeMenu === 'Pengaturan sistem' ? '#5c4535' : '#e2d8ce', background: activeMenu === 'Pengaturan sistem' ? '#e2d8ce' : 'transparent', transition:'0.2s', marginTop:'0.25rem'}}>
            <Settings size={18} /> Pengaturan sistem
          </div>
        </div>

        {/* FOOTER SIDEBAR ADMIN */}
        <div style={{padding:'1rem', borderTop:'1px solid rgba(255,255,255,0.1)', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div style={{display:'flex', alignItems:'center', gap:'0.75rem'}}>
            <div style={{width:'38px', height:'38px', background:'#a67c52', borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:'900', fontSize:'0.9rem', color: 'white'}}>
              {adminData.initials}
            </div>
            <div style={{maxWidth: '120px', overflow: 'hidden'}}>
              <p style={{fontSize:'0.85rem', fontWeight:'800', margin:0, color:'white', whiteSpace: 'nowrap', textOverflow: 'ellipsis'}}>{adminData.fullName}</p>
              <p style={{fontSize:'0.65rem', color:'#d1bfae', margin:0, whiteSpace: 'nowrap', textOverflow: 'ellipsis'}}>{adminData.role}</p>
            </div>
          </div>
          <LogOut size={18} color="#d1bfae" style={{cursor:'pointer'}} onClick={handleLogout} title="Keluar" />
        </div>
      </aside>
      
      {/* MAIN CONTENT AREA */}
      <main style={{flex: 1, padding: '2rem 3rem', overflowY: 'auto'}}>
        {renderContent()}
      </main>
    </div>
  );
};

export default DashboardAdmin;