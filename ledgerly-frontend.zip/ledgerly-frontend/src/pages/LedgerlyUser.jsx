import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, List, BarChart2, Cat, User, Target, 
  LogOut, Plus, Search, Trash2, Check, Edit3, Camera, CheckCircle2
} from 'lucide-react';

// INI KUNCI UTAMANYA: Mengambil logo dari folder yang sama!
import logoLedgerly from './logo.png';

import './LedgerlyUser.css';

const LedgerlyUser = () => {
  const navigate = useNavigate();
  const [activeMenu, setActiveMenu] = useState('Dashboard'); 

  // =====================================================================
  // 1. MESIN DATA UTAMA (STATE)
  // =====================================================================
  const [userData, setUserData] = useState({
    profile: {
      firstName: 'User', lastName: '', fullName: 'User Ledgerly', shortName: 'User', initials: 'U',
      email: 'user@email.com', phone: '+62 800-0000-0000', job: 'Pengguna', location: 'Indonesia', status: 'Aktif'
    },
    budget: { total: 2500000, makanan: 500000, belanja: 400000, hiburan: 300000, transport: 200000 },
    transactions: [
      { id: 1, date: '17 Mei 2026', desc: 'Kopi kekinian', cat: 'Makanan', amount: -35000, type: 'Keluar', flag: 'Normal' },
      { id: 2, date: '16 Mei 2026', desc: 'Gaji freelance', cat: 'Pemasukan', amount: 800000, type: 'Masuk', flag: 'Normal' },
      { id: 3, date: '15 Mei 2026', desc: 'Nonton bioskop', cat: 'Hiburan', amount: -55000, type: 'Keluar', flag: 'Boros' },
      { id: 4, date: '14 Mei 2026', desc: 'Beli Baju', cat: 'Belanja', amount: -150000, type: 'Keluar', flag: 'Waspada' }
    ]
  });

  useEffect(() => {
    const loginData = localStorage.getItem('userLoginData');
    const savedAppData = localStorage.getItem('ledgerlyAppData');

    if (savedAppData) {
      setUserData(JSON.parse(savedAppData));
    } else if (loginData) {
      const parsedLogin = JSON.parse(loginData);
      setUserData(prev => ({
        ...prev,
        profile: { ...prev.profile, ...parsedLogin }
      }));
    }
  }, []);

  const updateSystemData = (newData) => {
    setUserData(newData);
    localStorage.setItem('ledgerlyAppData', JSON.stringify(newData));
  };

  const handleLogout = () => {
    localStorage.removeItem('userLoginData');
    navigate('/login');
  };

  // =====================================================================
  // 2. FUNGSI PERHITUNGAN OTOMATIS GLOBAL
  // =====================================================================
  const formatRp = (angka) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(Math.abs(angka));
  
  const formatTanggalLengkap = (val) => {
    if (!val) return '';
    const parts = val.split('-');
    const namaBulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    if (parts.length === 3) return `${parseInt(parts[2], 10)} ${namaBulan[parseInt(parts[1], 10) - 1]} ${parts[0]}`;
    if (parts.length === 2) return `${namaBulan[parseInt(parts[1], 10) - 1]} ${parts[0]}`;
    return val;
  };
  
  const totalPemasukan = userData.transactions.filter(t => t.type === 'Masuk').reduce((acc, t) => acc + t.amount, 0);
  const totalPengeluaran = userData.transactions.filter(t => t.type === 'Keluar').reduce((acc, t) => acc + Math.abs(t.amount), 0);
  const sisaSaldo = totalPemasukan - totalPengeluaran; 
  const persenPengeluaran = Math.min(Math.round((totalPengeluaran / userData.budget.total) * 100), 100);

  // =====================================================================
  // 3. KOMPONEN HALAMAN (VIEW)
  // =====================================================================

  const ViewDashboard = () => (
    <div className="animate-fadeIn">
      <div className="u-header">
        <div><h2 className="u-header-title">Dashboard</h2><p className="u-header-subtitle">Selamat datang kembali, {userData.profile.firstName}!</p></div>
        <button className="u-btn-primary" onClick={() => setActiveMenu('Tambah Transaksi')}><Plus size={16}/> Catat transaksi</button>
      </div>

      <div className="u-grid-4">
        <div className="u-card" style={{borderTop: '4px solid #10b981', background:'#f8fafc'}}><p className="u-label">Total pemasukan</p><h3 style={{fontSize:'1.5rem', fontWeight:'900', color:'#10b981'}}>{formatRp(totalPemasukan)}</h3></div>
        <div className="u-card" style={{borderTop: '4px solid #ef4444'}}><p className="u-label">Total pengeluaran</p><h3 style={{fontSize:'1.5rem', fontWeight:'900', color:'#ef4444'}}>{formatRp(totalPengeluaran)}</h3><p style={{fontSize:'0.75rem', color:'#64748b', fontWeight:'700'}}>{persenPengeluaran}% anggaran</p></div>
        <div className="u-card" style={{borderTop: '4px solid #3b82f6'}}><p className="u-label">Sisa saldo</p><h3 style={{fontSize:'1.5rem', fontWeight:'900', color:'#3b82f6'}}>{formatRp(sisaSaldo)}</h3></div>
        <div className="u-card" style={{borderTop: '4px solid #f59e0b'}}><p className="u-label">Status Anggaran</p><h3 style={{fontSize:'1.5rem', fontWeight:'900', color:'#d97706'}}>{persenPengeluaran > 80 ? 'Waspada' : 'Aman'}</h3></div>
      </div>

      <div className="u-grid-3-2">
        <div className="u-card">
          <div style={{display:'flex', justifyContent:'space-between'}}><h3 style={{fontWeight:'800'}}>Pengeluaran mingguan</h3><span style={{fontSize:'0.75rem', fontWeight:'700', color:'#64748b'}}>Bulan ini</span></div>
          <div className="u-bar-chart">
            <div><div className="u-bar-col" style={{height:'40px'}}></div><span className="u-bar-label">M1</span></div>
            <div><div className="u-bar-col active" style={{height:'100px'}}></div><span className="u-bar-label" style={{color:'var(--u-brown-main)'}}>M2</span></div>
            <div><div className="u-bar-col" style={{height:'50px'}}></div><span className="u-bar-label">M3</span></div>
            <div><div className="u-bar-col" style={{height:'60px'}}></div><span className="u-bar-label">M4</span></div>
          </div>
        </div>
        <div className="u-card" style={{textAlign:'center'}}>
          <h3 style={{fontWeight:'800', textAlign:'left', marginBottom:'1rem'}}>Virtual Pet Kibi</h3>
          <div style={{width:'80px', height:'80px', background:'#fceee3', borderRadius:'50%', margin:'0 auto 1rem', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'2.5rem'}}>{persenPengeluaran > 80 ? '🙀' : '😸'}</div>
          <h4 style={{fontWeight:'800'}}>{persenPengeluaran > 80 ? 'Kibi Khawatir!' : 'Kibi Bahagia!'}</h4>
          <div style={{display:'flex', justifyContent:'space-between', fontSize:'0.75rem', fontWeight:'700', marginTop:'1rem', color:'#d97706'}}><span>Kesehatan {100 - persenPengeluaran}%</span></div>
          <div className="u-progress-bg"><div className="u-progress-fill" style={{width:`${100 - persenPengeluaran}%`, background:'#f59e0b'}}></div></div>
        </div>
      </div>
    </div>
  );

  const ViewTransaksi = () => {
    const [filterTanggal, setFilterTanggal] = useState('2026-05-17');

    return (
      <div className="animate-fadeIn">
        <div className="u-header">
          <div><h2 className="u-header-title">Transaksi</h2><p className="u-header-subtitle">{userData.transactions.length} transaksi tercatat</p></div>
          <button className="u-btn-outline" onClick={() => setActiveMenu('Tambah Transaksi')}><Plus size={16}/> Tambah transaksi</button>
        </div>
        <div className="u-card" style={{padding:'0', overflow:'hidden'}}>
          <div style={{padding:'1.5rem', display:'flex', gap:'1rem', borderBottom:'1px solid var(--u-border)', flexWrap:'wrap'}}>
            <div style={{position:'relative', flex:1, minWidth:'200px'}}><Search size={18} style={{position:'absolute', left:'1rem', top:'50%', transform:'translateY(-50%)', color:'#94a3b8'}}/><input className="u-input" style={{paddingLeft:'2.5rem'}} placeholder="Cari transaksi..." /></div>
            <select className="u-input" style={{width:'auto'}}><option>Semua kategori</option></select>
            <input type="date" className="u-input" style={{width:'auto', cursor:'pointer'}} value={filterTanggal} onChange={(e) => setFilterTanggal(e.target.value)} title="Pilih Tanggal"/>
            <select className="u-input" style={{width:'auto'}}><option>Semua tipe</option></select>
          </div>
          <table className="u-table">
            <thead><tr><th>Tanggal</th><th>Keterangan</th><th>Kategori</th><th>Jumlah</th><th>Tipe</th><th>Aksi</th></tr></thead>
            <tbody>
              {userData.transactions.map((tx) => (
                <tr key={tx.id}>
                  <td>{tx.date}</td>
                  <td style={{fontWeight:'700'}}>{tx.desc}</td>
                  <td><span className="u-badge" style={{background:'#f1f5f9', color:'#475569'}}>{tx.cat}</span></td>
                  <td style={{color: tx.type === 'Masuk' ? '#10b981' : '#dc2626', fontWeight:'800'}}>
                    {tx.type === 'Masuk' ? '+' : '-'}{formatRp(tx.amount)}
                  </td>
                  <td><span style={{fontSize:'0.75rem', fontWeight:'700'}}>{tx.type}</span></td>
                  <td><Edit3 size={16} color="#cbd5e1" style={{cursor:'not-allowed'}} title="Data permanen. Tidak dapat diubah."/></td>
                </tr>
              ))}
              {userData.transactions.length === 0 && (
                <tr><td colSpan="6" style={{textAlign:'center', padding:'2rem'}}>Belum ada transaksi.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const ViewTambahTransaksi = () => {
    const [desc, setDesc] = useState('');
    const [amount, setAmount] = useState('');
    const [type, setType] = useState('Keluar');
    const [cat, setCat] = useState('Makanan');

    const handleSave = () => {
      if(!desc || !amount) return alert("Keterangan dan Jumlah harus diisi!");
      const newTransaction = { id: Date.now(), date: new Date().toLocaleDateString('id-ID', { day:'numeric', month:'short', year:'numeric' }), desc, cat, amount: type === 'Keluar' ? -Math.abs(amount) : Math.abs(amount), type, flag: 'Normal' };
      updateSystemData({ ...userData, transactions: [newTransaction, ...userData.transactions] });
      setActiveMenu('Transaksi'); 
    };

    return (
      <div className="animate-fadeIn">
        <div className="u-header"><div><h2 className="u-header-title">Catat Transaksi</h2></div></div>
        <div className="u-grid-2">
          <div className="u-card">
            <h3 style={{fontWeight:'800', marginBottom:'1rem'}}>Detail Transaksi</h3>
            <label className="u-label">Jenis Transaksi</label>
            <div style={{display:'flex', gap:'1rem', marginBottom:'1rem'}}>
              <button className={type === 'Keluar' ? "u-btn-primary" : "u-btn-outline"} onClick={() => setType('Keluar')}>Pengeluaran</button>
              <button className={type === 'Masuk' ? "u-btn-primary" : "u-btn-outline"} onClick={() => setType('Masuk')}>Pemasukan</button>
            </div>
            <label className="u-label">Kategori</label>
            <select className="u-input" value={cat} onChange={e => setCat(e.target.value)} style={{marginBottom:'1rem'}}>
              <option value="Makanan">Makanan</option><option value="Belanja">Belanja</option>
              <option value="Hiburan">Hiburan</option><option value="Transport">Transport</option>
              <option value="Pemasukan">Gaji/Pemasukan</option>
            </select>
            <label className="u-label">Keterangan</label>
            <input className="u-input" placeholder="Contoh: Beli Kopi" value={desc} onChange={e => setDesc(e.target.value)} style={{marginBottom:'1rem'}}/>
            <label className="u-label">Jumlah (Rp)</label>
            <input className="u-input" type="number" placeholder="50000" value={amount} onChange={e => setAmount(e.target.value)} style={{marginBottom:'1.5rem'}}/>
            <div style={{display:'flex', gap:'1rem'}}>
              <button className="u-btn-primary" onClick={handleSave}><Check size={16}/> Simpan</button>
              <button className="u-btn-outline" onClick={() => setActiveMenu('Dashboard')}>Batal</button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const ViewProfil = () => {
    const [tempProfile, setTempProfile] = useState(userData.profile);
    const saveProfile = () => {
      const first = tempProfile.firstName.charAt(0).toUpperCase();
      const last = tempProfile.lastName ? tempProfile.lastName.charAt(0).toUpperCase() : '';
      updateSystemData({ ...userData, profile: { ...tempProfile, initials: first + last, shortName: `${tempProfile.firstName} ${last}.` } });
      alert("Profil berhasil diperbarui!");
    };

    return (
      <div className="animate-fadeIn">
        <div className="u-header"><div><h2 className="u-header-title">Profil saya</h2></div><button className="u-btn-outline" onClick={saveProfile}><Check size={16}/> Simpan perubahan</button></div>
        <div className="u-card">
          <div className="u-grid-2">
            <div><label className="u-label">Nama depan</label><input className="u-input" value={tempProfile.firstName} onChange={(e) => setTempProfile({...tempProfile, firstName: e.target.value})} /></div>
            <div><label className="u-label">Nama belakang</label><input className="u-input" value={tempProfile.lastName} onChange={(e) => setTempProfile({...tempProfile, lastName: e.target.value})} /></div>
            <div><label className="u-label">Email</label><input className="u-input" value={tempProfile.email} readOnly style={{background:'#f8fafc'}}/></div>
            <div><label className="u-label">Pekerjaan</label><input className="u-input" value={tempProfile.job} onChange={(e) => setTempProfile({...tempProfile, job: e.target.value})} /></div>
          </div>
        </div>
      </div>
    );
  };

  const ViewTargetAnggaran = () => {
    const [tempBudget, setTempBudget] = useState(userData.budget);
    const saveBudget = () => { updateSystemData({...userData, budget: tempBudget}); alert("Anggaran berhasil diperbarui!"); };

    return (
      <div className="animate-fadeIn">
        <div className="u-header"><div><h2 className="u-header-title">Target anggaran</h2></div><button className="u-btn-outline" onClick={saveBudget}><Check size={16}/> Simpan target</button></div>
        <div className="u-card"><h3 style={{fontWeight:'800', marginBottom:'1rem'}}>Total Anggaran Bulanan</h3><input className="u-input" type="number" value={tempBudget.total} onChange={e => setTempBudget({...tempBudget, total: parseInt(e.target.value)})} style={{marginBottom:'1rem'}}/></div>
      </div>
    );
  };

  const ViewAnalitik = () => {
    const [filterTanggal, setFilterTanggal] = useState('2026-05-17');
    const [filterWaktu, setFilterWaktu] = useState('Bulanan');

    const pengeluaranSaja = userData.transactions.filter(t => t.type === 'Keluar');
    const kategoriMap = {};
    pengeluaranSaja.forEach(t => { kategoriMap[t.cat] = (kategoriMap[t.cat] || 0) + Math.abs(t.amount); });
    const kategoriTerboros = Object.keys(kategoriMap).sort((a,b) => kategoriMap[b] - kategoriMap[a])[0] || '-';
    const totalPengeluaranKategori = Object.values(kategoriMap).reduce((a, b) => a + b, 0);

    const warnaKategori = { 'Makanan': '#10b981', 'Belanja': '#3b82f6', 'Hiburan': '#ef4444', 'Transport': '#f59e0b', 'Lainnya': '#8b5cf6' };

    let pieGradientCSS = [];
    let persenMulai = 0;
    Object.entries(kategoriMap).forEach(([kat, jumlah]) => {
      const persen = (jumlah / totalPengeluaranKategori) * 100;
      pieGradientCSS.push(`${warnaKategori[kat] || '#cbd5e1'} ${persenMulai}% ${persenMulai + persen}%`);
      persenMulai += persen;
    });

    const backgroundLingkaran = pieGradientCSS.length > 0 ? `conic-gradient(${pieGradientCSS.join(', ')})` : '#f1f5f9';

    let chartLabels = [], chartHeights = [];
    if (filterWaktu === 'Harian') { chartLabels = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min']; chartHeights = ['20px', '40px', '30px', '80px', '50px', '10px', '5px']; } 
    else if (filterWaktu === 'Mingguan') { chartLabels = ['Minggu 1', 'Minggu 2', 'Minggu 3', 'Minggu 4']; chartHeights = ['40px', '100px', '50px', '60px']; } 
    else { chartLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun']; chartHeights = ['60px', '80px', '70px', '90px', '120px', '50px']; }

    return (
      <div className="animate-fadeIn">
        <div className="u-header">
          <div><h2 className="u-header-title">Analitik pengeluaran</h2><p className="u-header-subtitle">Data analitik pada tanggal {formatTanggalLengkap(filterTanggal) || 'ini'}</p></div>
          <div style={{display: 'flex', gap: '1rem'}}>
            <select className="u-input" style={{width:'auto', cursor:'pointer'}} value={filterWaktu} onChange={e => setFilterWaktu(e.target.value)}>
              <option value="Harian">Per Hari (Minggu ini)</option><option value="Mingguan">Per Minggu (Bulan ini)</option><option value="Bulanan">Per Bulan (Tahun ini)</option>
            </select>
            <input type="date" className="u-input" style={{width:'auto', cursor:'pointer'}} value={filterTanggal} onChange={(e) => setFilterTanggal(e.target.value)} title="Pilih Tanggal Analitik"/>
          </div>
        </div>
        
        <div className="u-grid-4">
          <div className="u-card" style={{borderTop: '4px solid #ef4444'}}><p className="u-label">Total Pengeluaran</p><h3 style={{fontSize:'1.5rem', fontWeight:'900', color:'#ef4444'}}>{formatRp(totalPengeluaran)}</h3></div>
          <div className="u-card" style={{borderTop: '4px solid #3b82f6'}}><p className="u-label">Dana Yang Ada (Saldo)</p><h3 style={{fontSize:'1.5rem', fontWeight:'900', color:'#3b82f6'}}>{formatRp(sisaSaldo)}</h3></div>
          <div className="u-card" style={{borderTop: '4px solid #f59e0b'}}><p className="u-label">Kategori Terboros</p><h3 style={{fontSize:'1.5rem', fontWeight:'900', color:'#d97706'}}>{kategoriTerboros}</h3></div>
          <div className="u-card" style={{borderTop: '4px solid #10b981'}}><p className="u-label">Status Anggaran</p><h3 style={{fontSize:'1.5rem', fontWeight:'900', color:'#10b981'}}>{persenPengeluaran}% Terpakai</h3></div>
        </div>

        <div className="u-grid-2">
          <div className="u-card">
            <h3 style={{fontWeight:'800', marginBottom:'1rem'}}>Tren Pengeluaran {filterWaktu}</h3>
            <div className="u-bar-chart" style={{height:'150px', justifyContent: filterWaktu === 'Harian' ? 'space-between' : 'space-around'}}>
              {chartLabels.map((label, index) => (
                <div key={label}><div className={`u-bar-col ${index === chartLabels.length - 2 ? 'active' : ''}`} style={{height: chartHeights[index], width: filterWaktu === 'Bulanan' ? '30px' : '40px'}}></div><span className="u-bar-label" style={{color: index === chartLabels.length - 2 ? 'var(--u-brown-main)' : ''}}>{label}</span></div>
              ))}
            </div>
          </div>
          <div className="u-card">
            <h3 style={{fontWeight:'800', marginBottom:'1.5rem'}}>Distribusi Kategori</h3>
            <div style={{display:'flex', flexDirection:'column', gap:'1.25rem'}}>
              {Object.keys(kategoriMap).length > 0 ? Object.keys(kategoriMap).map(kat => {
                const persenKategori = Math.round((kategoriMap[kat] / totalPengeluaranKategori) * 100);
                const warnaLokal = warnaKategori[kat] || '#cbd5e1';
                return (
                  <div key={kat}>
                    <div style={{display:'flex', justifyContent:'space-between', fontSize:'0.875rem', fontWeight:'700', marginBottom:'0.5rem'}}><span>{kat}</span><span>{formatRp(kategoriMap[kat])}</span></div>
                    <div className="u-progress-bg" style={{height:'10px'}}><div className="u-progress-fill" style={{ width: `${persenKategori}%`, background: warnaLokal }}></div></div>
                  </div>
                );
              }) : <p style={{fontSize:'0.875rem', color:'#64748b'}}>Belum ada data pengeluaran dicatat.</p>}
            </div>
          </div>
        </div>

        <div className="u-card" style={{marginTop: '1.5rem'}}>
          <h3 style={{fontWeight:'800', marginBottom:'1.5rem', textAlign:'center'}}>Visualisasi Porsi Pengeluaran</h3>
          <div style={{display:'flex', justifyContent:'center', alignItems:'center', gap:'3rem', flexWrap:'wrap', padding: '1rem'}}>
            <div style={{width: '220px', height: '220px', borderRadius: '50%', background: backgroundLingkaran, boxShadow: '0 4px 15px rgba(0,0,0,0.1)'}}></div>
            <div style={{display:'flex', flexDirection:'column', gap:'1rem', minWidth:'150px'}}>
              {Object.keys(kategoriMap).length > 0 ? Object.keys(kategoriMap).map(kat => {
                const persenKategori = Math.round((kategoriMap[kat] / totalPengeluaranKategori) * 100);
                return (
                  <div key={kat} style={{display:'flex', alignItems:'center', gap:'0.75rem', fontSize:'0.9rem', fontWeight:'700'}}><span style={{width:'14px', height:'14px', borderRadius:'50%', background: warnaKategori[kat] || '#cbd5e1', display:'inline-block'}}></span><span style={{flex: 1}}>{kat}</span><span style={{color: '#64748b'}}>{persenKategori}%</span></div>
                );
              }) : <p style={{fontSize:'0.875rem', color:'#64748b'}}>Belum ada data</p>}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const ViewPeliharaan = () => {
    const kesehatan = Math.max(100 - persenPengeluaran, 0); 
    let moodEmoji = '😸'; let statusText = 'Sangat Sehat'; let statusColor = '#10b981'; let bgColor = '#d1fae5'; let message = 'Kibi sangat bangga! Pengeluaranmu sangat terkendali dan anggaranmu aman.';
    if (kesehatan < 50) { moodEmoji = '😿'; statusText = 'Kritis'; statusColor = '#ef4444'; bgColor = '#fee2e2'; message = 'Gawat! Kibi kelaparan dan sedih karena pengeluaranmu sudah menguras hampir seluruh anggaran.'; } 
    else if (kesehatan < 80) { moodEmoji = '🙀'; statusText = 'Agak Khawatir'; statusColor = '#f59e0b'; bgColor = '#fef3c7'; message = 'Kibi agak khawatir melihat dompetmu. Hati-hati dengan pengeluaran yang tidak perlu ya!'; }

    return (
      <div className="animate-fadeIn">
        <div className="u-header"><div><h2 className="u-header-title">Peliharaan virtual</h2></div></div>
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '2rem' }}>
          <div className="u-card" style={{ width: '100%', maxWidth: '600px', textAlign: 'center', padding: '3rem 2rem' }}>
            <div style={{ width: '160px', height: '160px', background: bgColor, borderRadius: '50%', margin: '0 auto 1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '6rem'}}>{moodEmoji}</div>
            <h2 style={{ fontSize: '2.5rem', fontWeight: '900', marginBottom: '0.5rem', color: 'var(--u-text-main)' }}>Kibi</h2>
            <span style={{ display: 'inline-block', padding: '0.5rem 1.5rem', borderRadius: '30px', background: bgColor, color: statusColor, fontWeight: '900', fontSize: '1rem', marginBottom: '2.5rem' }}>{statusText}</span>
            <div style={{ textAlign: 'left', marginBottom: '2.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.1rem', fontWeight: '900', marginBottom: '0.75rem' }}><span style={{ color: 'var(--u-text-main)' }}>Skor Kesehatan</span><span style={{ color: statusColor }}>{kesehatan}%</span></div>
              <div className="u-progress-bg" style={{ height: '20px', borderRadius: '10px' }}><div className="u-progress-fill" style={{ width: `${kesehatan}%`, background: statusColor, borderRadius: '10px'}}></div></div>
            </div>
            <div style={{ background: '#f8fafc', padding: '1.5rem', borderRadius: '1rem', border: '1px solid #e2e8f0' }}><p style={{ fontSize: '1.1rem', fontWeight: '700', color: '#475569', margin: 0, fontStyle: 'italic' }}>"{message}"</p></div>
          </div>
        </div>
      </div>
    );
  };

  const renderContent = () => {
    switch(activeMenu) {
      case 'Dashboard': return <ViewDashboard />;
      case 'Transaksi': return <ViewTransaksi />;
      case 'Tambah Transaksi': return <ViewTambahTransaksi />;
      case 'Analitik': return <ViewAnalitik />;
      case 'Peliharaan': return <ViewPeliharaan />;
      case 'Profil': return <ViewProfil />;
      case 'Target Anggaran': return <ViewTargetAnggaran />;
      default: return <ViewDashboard />;
    }
  };

  return (
    <div className="u-layout">
      {/* SIDEBAR */}
      <aside className="u-sidebar">
        <div className="u-sidebar-header">
          <div style={{display:'flex', alignItems:'center', gap:'0.5rem', marginBottom:'0.5rem'}}>
            
            {/* GAMBAR LOGO MENGGUNAKAN IMPORT */}
            <img 
              src={logoLedgerly} 
              alt="Logo Ledgerly" 
              style={{
                width: '32px', 
                height: '32px', 
                objectFit: 'contain', 
                background: 'white', 
                borderRadius: '8px', 
                padding: '2px'
              }} 
            />
            
            <h1 style={{fontSize:'1.25rem', fontWeight:'900', color:'white'}}>Ledgerly</h1>
          </div>
          <p style={{fontSize:'0.75rem', color:'#d1bfae', fontWeight:'600'}}>Halo, {userData.profile.firstName}!</p>
        </div>

        <div style={{flex:1, overflowY:'auto'}}>
          <div className="u-sidebar-section">Menu Utama</div>
          <a onClick={() => setActiveMenu('Dashboard')} className={activeMenu === 'Dashboard' ? 'u-menu-item active' : 'u-menu-item'}><LayoutDashboard size={18} /> Dashboard</a>
          <a onClick={() => setActiveMenu('Transaksi')} className={activeMenu === 'Transaksi' || activeMenu === 'Tambah Transaksi' ? 'u-menu-item active' : 'u-menu-item'}><List size={18} /> Transaksi <span style={{background:'var(--u-brown-main)', color:'white', fontSize:'0.6rem', padding:'2px 6px', borderRadius:'10px'}}>{userData.transactions.length}</span></a>
          <a onClick={() => setActiveMenu('Analitik')} className={activeMenu === 'Analitik' ? 'u-menu-item active' : 'u-menu-item'}><BarChart2 size={18} /> Analitik</a>
          <a onClick={() => setActiveMenu('Peliharaan')} className={activeMenu === 'Peliharaan' ? 'u-menu-item active' : 'u-menu-item'}><Cat size={18} /> Peliharaan</a>

          <div className="u-sidebar-section" style={{marginTop:'1rem'}}>Akun</div>
          <a onClick={() => setActiveMenu('Profil')} className={activeMenu === 'Profil' ? 'u-menu-item active' : 'u-menu-item'}><User size={18} /> Profil saya</a>
          <a onClick={() => setActiveMenu('Target Anggaran')} className={activeMenu === 'Target Anggaran' ? 'u-menu-item active' : 'u-menu-item'}><Target size={18} /> Target anggaran</a>
        </div>

        <div style={{padding:'1rem', borderTop:'1px solid rgba(255,255,255,0.1)', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div style={{display:'flex', alignItems:'center', gap:'0.75rem'}}>
            <div style={{width:'35px', height:'35px', background:'var(--u-brown-main)', borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:'bold', fontSize:'0.8rem', color:'white'}}>
              {userData.profile.initials}
            </div>
            <div>
              <p style={{fontSize:'0.875rem', fontWeight:'bold', margin:0, color:'white'}}>{userData.profile.shortName}</p>
              <p style={{fontSize:'0.6rem', color:'#d1bfae', margin:0}}>{userData.profile.status}</p>
            </div>
          </div>
          <LogOut size={18} color="#d1bfae" style={{cursor:'pointer'}} onClick={handleLogout} />
        </div>
      </aside>
      <main className="u-main">{renderContent()}</main>
    </div>
  );
};

export default LedgerlyUser;