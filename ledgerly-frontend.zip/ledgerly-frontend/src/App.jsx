import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register'; // Pastikan import ini ada!
import LedgerlyUser from './pages/LedgerlyUser';
import DashboardAdmin from './pages/DashboardAdmin';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} /> {/* Rute ini harus ada */}
        <Route path="/dashboard" element={<LedgerlyUser />} />
        <Route path="/admin" element={<DashboardAdmin />} />
        <Route path="/" element={<Navigate to="/login" replace />} />
      </Routes>
    </Router>
  );
}

export default App;